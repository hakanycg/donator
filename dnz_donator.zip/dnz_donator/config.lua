Config = {}

Config.Fahrzeuge = {
    

}

Config.AuthorizedAdmins = {'superadmin', 'admin'}